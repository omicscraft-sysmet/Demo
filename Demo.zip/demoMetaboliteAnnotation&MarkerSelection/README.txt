Demo1 consists of preprocessed metabolomics data acquired in the positive mode (Demo1a_metabolomics_data_pos.csv), proteomics data (Demo1c_proteomics_data_pos.csv), and glycomics data (Demo1e_glycomics_data_pos.csv) acquired from overlapping set of samples and three group of annotation files (Demo1b_metabolomics_group.csv, Demo1d_proteomics_group.csv, and Demo1f_glycomics_group.csv). The datasets can be used to test the marker selection modules.

Demo2 consists of preprocessed metabolomics data acquired in the positive mode (Demo2a_metabolomics_data_pos.csv) and a group annotation file (Demo2b_metabolomics_group.csv). The datasets can be used to test the marker selection modules.

Demo 3 consists of preprocessed metabolomics data acquired in the positive mode (Demo3a_metabolomics_data_pos.csv) and a group annotation file (Demo3_metabolomics_group.csv). The datasets can be used to test the marker selection modules.

Demo 4 consists of preprocessed metabolomics data acquired in the negative mode (Demo4a_metabolomics_data_neg.csv) and a group annotation file (Demo4b_metabolomics_group.csv). The datasets can be used to test the marker selection modules.

Demo 5 is a pipeline involving marker selection modules.