LC-MS processed data

Demo1a_peaks_pos.csv: a small subset of peaks detected in a metabolomics study using LC-MS in the positive mode. This demo dataset can be used to perform metabolite annotation using the Mass-Based Search module.

Demo1b_peaks_pos.csv: the same set of peaks as Demo1a but with adduct and isotope information  provided to some of the peaks. This demo dataset can be used to perform metabolite annotation using the Mass-Based Search followed by the Isotopic Pattern Analysis module. 

Demo2a_peaks_pos.csv: another small subset of peaks detected in a metabolomics study using LC-MS in the positive mode. This demo dataset can be used to perform metabolite annotation using the Mass-Based Search module.

Demo2b_peaks_pos.csv: the same set of peaks as Demo2a with adduct and isotope information provided to some of the peaks. This demo dataset can be used to perform metabolite annotation using the Mass-Based Search followed by the Isotopic Pattern Analysis module. 

Demo3a_peaks_neg.csv: an entire set of peaks detected by analysis of metabolomics data acquired using LC-MS in the negative mode. This demo dataset can be used to perform metabolite annotation using the Mass-Based Search module.

Demo3b_peaks_neg.csv: the same set of peaks as Demo3a with adduct and isotope information provided to some of the peaks. This demo dataset can be used to perform metabolite annotation using the Mass-Based Search followed by the Isotopic Pattern Analysis module.
LC-MS/MS processed dataDemo4a_MSMS_pos: a folder of 12 files each consisting of an MS/MS spectrum acquired in the positive mode. In each file, the first line presents the precursor m/z and retention time (RT) values separated by a comma. The next lines present a list of m/z and intensity pairs separated by space and entered one pair per line. This demo dataset can be used for metabolite annotation using the Spectral Matching module by uploading the 12 MS/MS spectra together.

Dem4b_MSMS_pos.txt: all 12 MS/MS spectra from Demo4a listed in one file. In the file, the first line presents the precursor m/z and retention time (RT) values separated by a comma. The next lines present a list of m/z and intensity pairs separated by space and entered one pair per line. This format is repeated for all remaining MS/MS spectra, each separated by a blank line. This demo dataset can be used for metabolite annotation using the Spectral Matching module.Demo5a_MSMS_neg: a folder of 4 files each consisting of an MS/MS spectrum acquired in the negative. In each file, the first line presents the precursor m/z and retention time (RT) values separated by a comma. The next lines present a list of m/z and intensity pairs separated by space and entered one pair per line. This demo dataset can be used for metabolite annotation using the Spectral Matching module by uploading the 4 MS/MS spectra together.
Demo5b_MSMS_neg.txt: all 4 MS/MS spectra from Demo5a listed in one file. In the file, the first line presents the precursor m/z and retention time (RT) values separated by a comma. The next lines present a list of m/z and intensity pairs separated by space and entered one pair per line. This format is repeated for all remaining MS/MS spectra, each separated by a blank line. This demo dataset can be used for metabolite annotation using the Spectral Matching module.GC-MS processed dataDemo6a_EI.txt: a set of 5 EI spectra acquired by GC-MS. This demo dataset can be used for batch metabolite annotation using the Spectral Matching module by choosing the GC-MS platform.

Demo6b_EI.txt: the same datasets as Demo8a but combined in one file. This demo dataset can be used for metabolite annotation using the Spectral Matching module by choosing the GC-MS platform.

LC-MS/MS unprocessed data

Demo7a_mzXML_pos: a folder of 10 mzXML files acquired by LC-MS/MS in the positive mode and a precursor file that indicates the m/z and RT values of all precursor ions expected for each mZXML file. This demo dataset can be used for annotation of the analytes indicated in the precursor file using the Spectral Matching module. The module may extract the MS/MS spectra guided by the m/z provided in the precursor file. Users may choose to use the RT values in the precursor file or let the module automatically choose high quality MS/MS spectra across all scans. This demo dataset can also be used for peak detection using the Peak Detection & Alignment module. 

Demo7b_mzML_pos: the same datasets as Demo7a but in mzML format.
Demo8a_mzXML_neg: a folder of 3 mzXML files acquired by LC-MS/MS in the negative mode and a precursor file that indicates the m/z and RT values of all precursor ions expected for each mZXML file. This demo dataset can be used for annotation of the analytes indicated in the precursor file using the Spectral Matching module. The module may extract the MS/MS spectra guided by the m/z provided in the precursor file. Users may choose to use the RT values in the precursor file or let the module automatically choose high quality MS/MS spectra across all scans. This demo dataset can also be used for peak detection using the Peak Detection & Alignment module.
Demo8b_mzML_neg: the same datasets as Demo8a but in mzML format.




